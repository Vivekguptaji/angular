import { Ingredent } from '../share/Ingredents.model';
import { EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
export class ShoppingListService {
  //ingredentChange = new EventEmitter<Ingredent[]>();/*converted to Subject*/
  ingredentChange = new Subject<Ingredent[]>();
  private ingredents: Ingredent[] = [
    new Ingredent('Chilli', 5),
    new Ingredent('Apple', 15),
    new Ingredent('Tomato', 20),
  ];

  getIngredents = () => {
    return this.ingredents.slice();
  };
  addIngredent(data: Ingredent) {
    this.ingredents.push(data); /*Item was add but due to slice not shared*/
    //this.ingredentChange.emit(this.ingredents.slice()); /*ngOnInit call this*/
    this.ingredentChange.next(this.ingredents.slice());
    /*after onvert subject, now use nex*/
  }
}
