export class Ingredent {
  constructor(public name: string, public amount: number) {}
}
